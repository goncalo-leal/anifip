# sender.py
"""
Main sender module

This module is responsible for sending the MIDI file to the worker nodes. It uses the Pygame library 
to play the MIDI file and the Mido library to handle MIDI commands. The sender uses protobufs to 
serialize and deserialize the ad-hoc network messages.
"""

import threading
import json
import os
from utils import get_logger, config, midi, messages
from mqtt_client import client, ack_event, connect, mqtt
from time import ctime

# Initialize logger
log = get_logger()
broadcast_data_msg_sqc_number = 0


def wait_for_init_ack_and_start_threads(midi_file_path):
    log.info("Waiting for ACK...")
    ack_event.wait()  # Block until the event is set
    log.info("ACK received, starting print and play threads")


# Connect to the MQTT broker
connect()

def on_message(client, userdata, msg):
    global broadcast_data_msg_sqc_number
    log.info("Message received on topic %s: %s", msg.topic, msg.payload)
    try:
        message = json.loads(msg.payload)
        ack_check = messages.ack_checker(message, broadcast_data_msg_sqc_number)
        if ack_check:
            ack_event.set()
    except Exception as e:
        log.error("Error processing message: %s", e)

client.on_message = on_message

# Load the MIDI file with error handling
midi_file_path = os.path.join("..", "midi_files", config.MIDI_FILE)
print(midi_file_path)
try:
    with open(midi_file_path, "rb") as file:
        midi_data = file.read()
except FileNotFoundError:
    log.error("MIDI file not found: %s", midi_file_path)
    raise
except Exception as e:
    log.error("Error reading MIDI file: %s", e)
    raise

# Create the JSON Message
broadcast_data_msg_dict = messages.create_message("BROADCAST_DATA", data=midi_file_path)
broadcast_data_msg = json.dumps(broadcast_data_msg_dict)
broadcast_data_msg_sqc_number = broadcast_data_msg_dict.get("sequence_number")

# Publish the MIDI message with error handling
try:
    result = client.publish(config.TOPIC_MIDI, broadcast_data_msg)
    if result.rc != mqtt.MQTT_ERR_SUCCESS:
        log.error("Failed to publish MIDI message: %d", result.rc)
except Exception as e:
    log.error("Error publishing MIDI message: %s", e)
    raise

log.info("MIDI file sent")

# Thread to wait for ACK init and start print and play threads
wait_thread = threading.Thread(target=wait_for_init_ack_and_start_threads, args=(midi_file_path,))
wait_thread.daemon = True
wait_thread.start()

input_port = midi.get_input_port()

# Start the thread for reading MIDI messages
read_thread = threading.Thread(target=midi.read_midi_messages, args=(input_port, False))
read_thread.daemon = True
read_thread.start()

# Wait for the threads to finish
read_thread.join()
wait_thread.join()
