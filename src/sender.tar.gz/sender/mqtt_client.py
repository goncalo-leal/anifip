import threading
from paho.mqtt import client as mqtt
from utils import get_logger, config, messages
import json

log = get_logger()
ack_event = threading.Event()

# Initialize the MQTT client
client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        log.info("Connected to MQTT Broker!")
    else:
        log.error("Failed to connect, return code %d\n", rc)

client.on_connect = on_connect


def connect():
    try:
        client.connect(config.MQTT_BROKER, config.MQTT_PORT, 60)
        client.loop_start()
        client.subscribe(config.TOPIC_MIDI)
    except Exception as e:
        log.error("Failed to connect to MQTT Broker: %s", e)
        raise

# Expose client and ack_event for use in other modules
__all__ = ["client", "ack_event", "connect"]
